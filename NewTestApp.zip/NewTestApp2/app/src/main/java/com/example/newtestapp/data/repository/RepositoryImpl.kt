package com.example.newtestapp.data.repository

import com.example.newtestapp.data.models.AllTeansModel
import com.example.newtestapp.data.remote.ApiCall
import javax.inject.Inject

class RepositoryImpl @Inject constructor(private val apiCall: ApiCall) : Repository {
    override suspend fun getAlTeams(): AllTeansModel {
        return apiCall.getAllTeams()
    }
}