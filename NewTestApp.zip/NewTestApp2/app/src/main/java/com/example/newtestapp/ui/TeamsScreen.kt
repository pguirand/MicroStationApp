package com.example.newtestapp.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.Surface
import androidx.compose.material.Text
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import coil.compose.rememberAsyncImagePainter
import com.example.newtestapp.common.ApiConstants
import com.example.newtestapp.data.models.AllTeansModel
import com.example.newtestapp.data.models.TeamModel
import com.example.newtestapp.data.remote.ApiResponse
import com.example.newtestapp.viewmodels.TeamsViewModel
import kotlin.math.sin


@Composable
fun TeamsScreen(
    modifier: Modifier = Modifier,
    viewModel: TeamsViewModel = hiltViewModel()
) {
    val teamListState by viewModel.teamList.collectAsState()

    when(teamListState) {
        is ApiResponse.Error -> {
            Column(
                modifier = Modifier
                    .padding(8.dp)
                    .fillMaxSize(),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = (teamListState as ApiResponse.Error).exceptionMsg,
                    color = Color.Red
                )
            }
        }
        ApiResponse.Loading -> {
            Box(modifier = Modifier.fillMaxSize().background(Color.LightGray)) {
                CircularProgressIndicator(
                    modifier = Modifier
                        .background(Color.White)
                        .align(Alignment.Center),
                    color = Color.Blue
                )
            }
        }
        is ApiResponse.Success -> {
            val allTeansModel = (teamListState as ApiResponse.Success<AllTeansModel>).data
            val teamList = allTeansModel.teams?.filterNotNull() ?: emptyList()
            Surface(
                modifier.fillMaxSize().padding(16.dp)
            ) {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                ) {
                    items(teamList) { team ->
                        TeamItem(singleTeamModel = team)
                    }
                }
            }
        }


    }
}


@Composable
fun TeamItem(
    singleTeamModel: TeamModel
) {
    val logoUrl = "https://squiggle.com.au"+singleTeamModel.logo
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(4.dp)
    ) {
        Row(
            modifier = Modifier
                .padding(1.dp)
                .fillMaxSize()
                .background(Color.Cyan)
                .clip(RoundedCornerShape(8.dp))
                .padding(4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(50.dp)
        ) {
            Image(
                modifier = Modifier
                    .size(50.dp)
                    .padding(4.dp),
                painter = rememberAsyncImagePainter(logoUrl),
                contentDescription = singleTeamModel.name
            )
            Text(
                text = singleTeamModel.name?:"N/A"
            )
        }
    }
}













