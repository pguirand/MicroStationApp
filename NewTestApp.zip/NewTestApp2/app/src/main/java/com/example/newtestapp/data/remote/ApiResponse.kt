package com.example.newtestapp.data.remote

sealed class ApiResponse<out T:Any> {
    data class Success<out T:Any>(val data:T) : ApiResponse<T>()
    data class Error(val exceptionMsg:String) : ApiResponse<Nothing>()
    data object Loading : ApiResponse<Nothing>()
}