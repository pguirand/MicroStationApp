package com.example.newtestapp.data.repository

import com.example.newtestapp.data.models.AllTeansModel

interface Repository {
    suspend fun getAlTeams() : AllTeansModel
}