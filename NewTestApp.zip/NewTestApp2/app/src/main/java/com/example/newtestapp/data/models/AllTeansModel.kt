package com.example.newtestapp.data.models


import com.google.gson.annotations.SerializedName

data class AllTeansModel(
    @SerializedName("teams")
    val teams: List<TeamModel?>?
)