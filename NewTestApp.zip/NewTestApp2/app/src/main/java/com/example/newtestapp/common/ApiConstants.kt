package com.example.newtestapp.common

object ApiConstants {

    const val BASE_URL = "https://api.squiggle.com.au/"
    const val ALL_TEAMS_ENDPOINT = "?q=teams"
}
