package com.example.newtestapp.data.remote

import com.example.newtestapp.common.ApiConstants
import com.example.newtestapp.data.models.AllTeansModel
import retrofit2.http.GET

interface ApiCall {
    @GET(ApiConstants.ALL_TEAMS_ENDPOINT)
    suspend fun getAllTeams() : AllTeansModel
}