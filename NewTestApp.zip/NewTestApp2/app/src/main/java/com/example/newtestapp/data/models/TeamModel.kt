package com.example.newtestapp.data.models


import com.google.gson.annotations.SerializedName

data class TeamModel(
    @SerializedName("abbrev")
    val abbrev: String?,
    @SerializedName("debut")
    val debut: Int?,
    @SerializedName("id")
    val id: Int?,
    @SerializedName("logo")
    val logo: String?,
    @SerializedName("name")
    val name: String?,
    @SerializedName("retirement")
    val retirement: Int?
)