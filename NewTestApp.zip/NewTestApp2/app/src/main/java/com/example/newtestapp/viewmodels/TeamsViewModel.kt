package com.example.newtestapp.viewmodels

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.newtestapp.data.models.AllTeansModel
import com.example.newtestapp.data.remote.ApiResponse
import com.example.newtestapp.data.repository.Repository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class TeamsViewModel @Inject constructor(private val repository: Repository) : ViewModel(){
    private val _teamList = MutableStateFlow<ApiResponse<AllTeansModel>>(ApiResponse.Loading)
    val teamList: StateFlow<ApiResponse<AllTeansModel>> = _teamList

    init {
        getAllTeams()
    }


    private fun getAllTeams() {
        viewModelScope.launch {
            _teamList.value = ApiResponse.Loading
//            delay(5000)
//            _teamList.value = ApiResponse.Error("Failed to load teams. please try again")

            try {
                val teams = repository.getAlTeams()
                Log.d("API_RESPONSE", "$teams")
                _teamList.value = ApiResponse.Success(teams)
            } catch (e: Exception) {
                Log.e("error", e.message?:"Unexpected Error")
                _teamList.value = ApiResponse.Error(e.message?:"Unexpected Error")
            }
        }
    }
}